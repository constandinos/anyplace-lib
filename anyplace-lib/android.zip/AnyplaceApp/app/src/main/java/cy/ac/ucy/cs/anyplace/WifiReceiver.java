package cy.ac.ucy.cs.anyplace;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public abstract class WifiReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context paramContext, Intent paramIntent) {


    }

}

