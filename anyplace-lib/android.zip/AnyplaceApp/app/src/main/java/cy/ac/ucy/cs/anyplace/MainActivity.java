package cy.ac.ucy.cs.anyplace;

import androidx.appcompat.app.AppCompatActivity;
import android.widget.Button;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import cy.ac.ucy.anyplace.AnyplacePost;

public class MainActivity extends AppCompatActivity{
    private static final String TAG = MainActivity.class.getSimpleName();

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        System.out.println(TAG+"Hello");

        /*
        SimpleWifiManager fingerprints = SimpleWifiManager.getInstance();
        fingerprints.startScan();
        System.out.println(fingerprints.getIsScanning());
        System.out.println(fingerprints.getScanResults());
        */

        final Button button = findViewById(R.id.button);
        final EditText text = findViewById(R.id.textArea);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                new Thread(new Runnable(){
                    @Override
                    public void run() {
                        try {
                            String str = "username_1373876832005";
                            String response;
                            AnyplacePost client = new AnyplacePost("ap.cs.ucy.ac.cy", "443");
                            response = client.allBuildingFloors(str);
                            text.setText(response);

                        }
                        catch (Exception ex) {
                            ex.printStackTrace();
                        }
                    }
                }).start();

            }
        });
    }
}
